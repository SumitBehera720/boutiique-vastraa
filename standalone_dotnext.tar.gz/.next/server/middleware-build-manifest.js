globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/y5ThYqCGGm96uAKqDZ_TC/_buildManifest.js",
    "static/y5ThYqCGGm96uAKqDZ_TC/_ssgManifest.js",
    "static/y5ThYqCGGm96uAKqDZ_TC/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2zjueh7t2vecu.js",
    "static/chunks/0ha4m18glnjqn.js",
    "static/chunks/0-838pqxt_3gx.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/1trqy_e13immx.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/turbopack-08w8mt_qjab_t.js"
  ]
};
