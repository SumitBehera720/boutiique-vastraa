var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__1__fnks._.js")
R.c("server/chunks/[root-of-the-server]__1r01cl_._.js")
R.c("server/chunks/node_modules_next_dist_1_lpwll._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_15vc_89.js")
R.m(33102)
module.exports=R.m(33102).exports
