var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__1gew-3q._.js")
R.c("server/chunks/[root-of-the-server]__1r01cl_._.js")
R.c("server/chunks/node_modules_next_dist_1_lpwll._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_05l5km9.js")
R.m(8922)
module.exports=R.m(8922).exports
